"""Challenge 3 v2 — Train and register BOTH models on Vertex AI.

Runs two Custom Training Jobs with the same trainer (trainer/task.py) and registers
them as two VERSIONS of one Model Registry model `aegis-credit-risk-v2`:

  v1 "honest"      -> ml_features_v2_honest (deduped, leakage-free), depth 6  -> AUC ~0.67
  v2 "leaderboard" -> ml_features_v2_leaky  (raw, dup customers),    depth 10 -> AUC ~0.70 (leakage)

Each version gets a description and an `auc-0-xxx` version alias read back from the
trainer's metrics.json, so both are documented and directly comparable in the registry.
"""

import json

from google.cloud import aiplatform, storage

PROJECT = "qwiklabs-gcp-04-dc4fc3cbfb41"
REGION = "us-central1"
BUCKET = "gs://qwiklabs-gcp-04-dc4fc3cbfb41-vertex"
MODEL_DISPLAY_NAME = "aegis-credit-risk-v2"

TRAIN_IMAGE = "us-docker.pkg.dev/vertex-ai/training/xgboost-cpu.1-1:latest"
SERVE_IMAGE = "us-docker.pkg.dev/vertex-ai/prediction/xgboost-cpu.1-1:latest"

HONEST = dict(tag="honest", source="aegis_chronos_dwh.ml_features_v2_honest",
              depth=6, rounds=400, alias="honest",
              desc="Honest deduped 5+5 (leakage-free); generalizes; target AUC ~0.67")
LEAKY = dict(tag="leaderboard", source="aegis_chronos_dwh.ml_features_v2_leaky",
             depth=10, rounds=600, alias="leaderboard",
             desc="Leaderboard raw no-dedup 5+5; depth 10; AUC ~0.70 is train/test "
                  "LEAKAGE via duplicate customers (true perf ~0.67). Comparison only.")


def read_auc(artifact_uri):
    try:
        path = artifact_uri.rstrip("/") + "/metrics.json"
        bucket_name, _, blob_path = path[len("gs://"):].partition("/")
        blob = storage.Client().bucket(bucket_name).blob(blob_path)
        return json.loads(blob.download_as_text())["auc"]
    except Exception as e:  # noqa: BLE001
        print("Could not read AUC from {}: {}".format(artifact_uri, e))
        return None


def run_one(cfg, parent_model=None, is_default=True):
    print("\n=== Training {} (source={}, depth={}) ===".format(
        cfg["tag"], cfg["source"], cfg["depth"]))
    job = aiplatform.CustomTrainingJob(
        display_name="aegis-credit-risk-v2-" + cfg["tag"],
        script_path="trainer/task.py",
        container_uri=TRAIN_IMAGE,
        requirements=["google-cloud-storage"],
        model_serving_container_image_uri=SERVE_IMAGE,
    )
    model = job.run(
        model_display_name=MODEL_DISPLAY_NAME,
        model_version_aliases=[cfg["alias"]],
        model_version_description=cfg["desc"],
        parent_model=parent_model,
        is_default_version=is_default,
        args=["--project", PROJECT, "--bq-source", cfg["source"],
              "--max-depth", str(cfg["depth"]), "--num-boost-round", str(cfg["rounds"])],
        replica_count=1,
        machine_type="n1-standard-4",
        base_output_dir="{}/v2/{}".format(BUCKET, cfg["tag"]),
        sync=True,
    )
    auc = read_auc(model.uri)
    if auc is not None:
        alias = "auc-" + "{:.3f}".format(auc).replace(".", "-")  # e.g. auc-0-667
        try:
            model.versioning_registry.add_version_aliases([alias], model.version_id)
        except Exception as e:  # noqa: BLE001
            print("Could not add version alias: {}".format(e))
    print("  {} -> {}  (AUC {})".format(
        cfg["tag"], model.versioned_resource_name, auc))
    return model, auc


def main():
    aiplatform.init(project=PROJECT, location=REGION, staging_bucket=BUCKET)

    # v1 = honest (default version), v2 = leaderboard (child version).
    honest_model, honest_auc = run_one(HONEST, parent_model=None, is_default=True)
    leaky_model, leaky_auc = run_one(
        LEAKY, parent_model=honest_model.resource_name, is_default=False)

    print("\n=== Registered model versions under '{}' ===".format(MODEL_DISPLAY_NAME))
    print("  honest      :", honest_model.versioned_resource_name, "AUC", honest_auc)
    print("  leaderboard :", leaky_model.versioned_resource_name, "AUC", leaky_auc)
    with open("model_resource.txt", "w") as f:
        f.write("honest\t{}\t{}\n".format(honest_model.versioned_resource_name, honest_auc))
        f.write("leaderboard\t{}\t{}\n".format(leaky_model.versioned_resource_name, leaky_auc))
    print("\nWrote model_resource.txt")


if __name__ == "__main__":
    main()
