# Challenge 3 — Detailed Experiment Report (Reaching for AUC > 0.70)

**Goal:** Our deployed XGBoost credit-risk model (predicting `default_flag`) sits at **AUC 0.671**.
A peer team reportedly reached **> 0.70 with ~10 features** (5 from `customer_master`, 5 from
`loan_applications`). This report documents every experiment run to understand and close that
gap — each with its **motivation**, **method**, and **result**.

**Headline conclusion:** The honest, leakage-free ceiling on this feature set is **~0.66–0.67**.
The "0.70" is **train/test leakage** caused by duplicate customers leaking across the split. We
reproduced it (0.705 locally, 0.700 on Vertex) and registered both an honest model (0.660) and a
leaderboard-matching model (0.700) as separate versions.

Environment: project `qwiklabs-gcp-04-dc4fc3cbfb41`, dataset `aegis_chronos_dwh`, region
`us-central1`. Local XGBoost 3.3 (installed to `/tmp/pylibs`); Vertex prebuilt `xgboost-cpu.1-1`.

---

## Phase 0 — Understand the existing solution

**Motivation:** Know exactly what produced 0.671 before changing anything.

**Method:** Read `../challenge03/` (`sql/build_features.sql`, `trainer/task.py`,
`submit_training.py`, `summary_with_details.md`).

**Result:** Current model = XGBoost native API, **19 base features → 38 one-hot columns**,
including 4 bank + 1 bureau features that are very sparsely populated. Deduped customers, dropped
`-999999` label sentinels, `scale_pos_weight`, depth 6, 400 rounds, **no early stopping**. Test
AUC 0.671 on a single stratified 80/20 split (seed 42).

---

## Phase 1 — BigQuery data profiling (where is the signal?)

### 1.1 Schema audit of all four tables
**Motivation:** Check for unused high-signal columns the current pipeline might be ignoring.
**Result:** No hidden columns — the pipeline already pulls every usable field. `customer_master`
and `loan_applications` are the only feature-bearing tables besides the sparse bank/bureau ones.

### 1.2 Numeric data-quality profile
**Motivation:** The dataset is "dirty" (the `-999999` label sentinel was known); maybe feature
columns are dirty too and being fed raw.
**Result (dirty columns found):**
- `num_delayed_payments`: range **-3 to 4399** (939 negatives) — fed raw.
- `num_active_accounts`: range **-100 to 2584** (6025 negatives) — fed raw.
- `dti_ratio`: max **4997** (outliers).
- `monthly_income_usd`: max ~2.0M (outliers).
- `credit_score_bureau`: clean 300–850. No `-999999` in any feature column.

### 1.3 Feature → target signal (correlation + group default rates)
**Motivation:** Rank features by predictive power to find the real ~10.
**Result:**
- Numeric |corr|: `num_delayed_payments` 0.169 (cleaned), `interest_rate_pct` 0.130,
  `credit_score_bureau` 0.112, `num_active_accounts` 0.111, `loan_amount` 0.097,
  `years_at_residence` 0.087. **Noise (~0):** `monthly_income_usd` 0.0005, `dti_ratio` 0.007,
  `age` 0.017, `loan_term_months` 0.003.
- Categorical separation: **`credit_mix` strong** (BAD 0.519 vs GOOD 0.307); `residence_type`
  (0.41 vs 0.34) and `approval_status` (0.40 vs 0.35) moderate; `payment_of_min_amount` weak;
  **`loan_purpose` = pure noise** (every value ~0.37).
- Bank features populated for only **2,097 / 157,500** rows (1.3%); bureau **10,490** (6.7%).

**Initial (later overturned) hypothesis:** 0.671 is dragged down by (a) two strong features fed
raw/dirty and (b) ~30 noise/near-empty one-hot columns. Predicted that cleaning + selecting ~10
features would lift AUC.

---

## Phase 2 — BigQuery ML experiments (fast iteration)

**Motivation:** Test the cleaning/selection hypothesis quickly (~1–2 min/model) before touching
the production pipeline. Model = `BOOSTED_TREE_CLASSIFIER`, 80/20 eval split.

| Exp | What | Motivation | AUC |
|---|---|---|---|
| A | Current 19 features (raw) | baseline parity | **0.6521** |
| B | 19 features, clip dirty cols to NULL, `credit_mix='_'`→NULL | does cleaning help? | 0.6351 |
| C | 10-feature cleaned shortlist | the predicted winner | 0.6407 |
| D | 9 features (drop `payment_of_min_amount`) | ablation | 0.6143 |

**Result / surprise:** Cleaning and feature-dropping both made it **worse**. Hypothesis
falsified. Two lessons: (1) BQML mean-imputes the NULLs I created, destroying information;
(2) the "dirty" extreme values may carry signal, not noise.

### 2.1 Re-EDA prompted by the surprise
**Motivation:** Understand why clipping hurt.
**Result:** `num_delayed_payments` is a **clean monotonic predictor across its full range**
(0–5→0.238 default, 6–15→0.369, 16–30→0.452, 100+→0.454) — the "extreme" values are genuinely
high-risk, so clipping them to NULL removed a high-default group. `credit_score_bureau` is
predictive mainly in its **bottom decile** (300–496→0.515; middle deciles flat ~0.37;
top→0.291) — a nonlinearity trees capture but linear/imputation underplays. Engineered ratios
(`loan_to_income`, `la×ir`, `debt_load`) showed **no** correlation gain over existing features.

| Exp | What | Motivation | AUC |
|---|---|---|---|
| E | 10-feature shortlist **raw** (no clip), tuned, no class weights | raw vs cleaned | 0.6607 |
| F | Full 19 **raw**, tuned | best BQML config | **0.6663** |
| G | Full 19 raw + 3 engineered ratios, tuned | do ratios help? | 0.6602 |

**Result:** Raw ≫ cleaned (confirmed). Tuning added ~0.014. Engineered ratios did **not** help.
BQML caps ~0.666 — and crucially **BQML (0.652) underperforms the real XGBoost trainer (0.671)
on identical features** because it mean-imputes missing values. → BQML is a *pessimistic proxy*;
switched to local XGBoost for trustworthy numbers.

---

## Phase 3 — Local XGBoost (true-to-trainer, native NaN + categorical)

Data pulled once and cached: `/tmp/credit_data.parquet` (deduped) and later
`/tmp/credit_raw.parquet` (raw). Harness uses native categorical features so each categorical
counts as **one** feature (matching the "10 features" framing). Scripts in `experiments/`.

### 3.1 Baseline, single-feature AUC, importance
**Motivation:** Establish the real XGBoost ceiling and rank features properly.
**Result:** **Full 16-feature AUC = 0.6728** (already > production 0.671). Best single-feature
AUCs: `num_delayed_payments` 0.599, `interest_rate_pct` 0.578, `credit_mix` 0.578,
`num_active_accounts` 0.567, `credit_score_bureau` 0.558, `dti_ratio` 0.557, `loan_amount` 0.557.
`payment_of_min_amount` has low solo AUC (0.524) but **high gain importance** (interaction
effect). `loan_purpose`, `loan_term_months`, `days_since_application`, `age` ≈ noise (~0.50).

### 3.2 Greedy forward selection (cap 5 customer + 5 loan)
**Motivation:** Find the optimal 5+5 directly.
**Result:** AUC **plateaus at ~0.673** after 8 features (5 customer / 3 loan); adding more loan
features (`loan_purpose`, `loan_term_months`) slightly *hurt*. Feature selection alone cannot
reach 0.70 — a ~0.027 gap remained.

### 3.3 Randomized hyperparameter search (25 configs each)
**Motivation:** Maybe tuning bridges the gap.
**Result:** 5+5 best **0.6747**, full-16 best **0.6788** — but the winning configs were depth 10
(overfit-prone). Still short of 0.70.

### 3.4 Stratified 5-fold CV of the "tuned" configs
**Motivation:** Single-split numbers are noisy; get an honest estimate + check overfitting.
**Result:** 5+5 CV **0.6738 ± 0.005 (train 0.806)**; full-16 CV **0.6779 ± 0.005 (train 0.866)**.
**Severe overfitting** — the depth-10 "tuned" gains were single-split optimism, not real.

### 3.5 Generalization-focused regularized CV
**Motivation:** Tune *for generalization* (shallow depth, high `min_child_weight`, `reg_lambda`)
— the proper way to find the true ceiling.
**Result:** Every regularized config converged to **~0.671 CV AUC** (full 16) / **0.670** (5+5).
**Definitive: the honest generalizable ceiling is ~0.67**, identical to production.

---

## Phase 4 — Hunting the missing 0.03 (structural causes)

### 4.1 "Bookkeeping"/date columns as hidden signal
**Motivation:** In synthetic data, `temp_migration_flag`/`legacy_system_id` or date parts can
leak the label.
**Result:** All flat (~0.37 default rate across every value/month). No hidden signal.

### 4.2 Drop dirty rows entirely (instead of nulling)
**Motivation:** If corrupted rows add label noise, training+evaluating on a clean subset could
legitimately raise measurable AUC.
**Result:** Clean subset (107,536 of 157,500 rows) → **0.671** (vs 0.671 full). No change, and
it discarded 32% of data. Not the cause.

### 4.3 Join cardinality check — the breakthrough
**Motivation:** Verify the join is 1:1 (never confirmed earlier).
**Result:** `customer_master` (valid) = 157,500 rows but only **150,000 distinct `customer_id`**;
`loan_applications` = 160,650 rows but only **153,150 distinct `loan_id`**. **Both sides have
duplicates** → the join can place the same customer in multiple rows.

### 4.4 Leakage test: random split vs customer-grouped split
**Motivation:** Duplicates + a random split = same customer in train *and* test = leakage. Quantify it.
**Method:** Raw non-deduped join (165,373 rows / 150,000 customers); `StratifiedKFold` (random)
vs `StratifiedGroupKFold` (grouped by `customer_id`), depth 8.
**Result:**
- Random split (leakage allowed): **AUC 0.6907**
- Grouped split (leakage-free): **AUC 0.6673**
- **Leakage inflation = +0.0234** — the smoking gun.

### 4.5 Reproduce the exact 0.70 claim
**Motivation:** Confirm the peer recipe (5+5, no dedup, deep model, single random split).
**Result (raw data, 5+5, single 80/20 split, seed 42):**

| Depth | Rounds | AUC |
|---|---|---|
| 6 | 400 | 0.6734 |
| 8 | 500 | 0.6893 |
| 10 | 600 | **0.7054** ✅ |

**Confirmed:** "0.70 with 10 features" = no dedup + random split + deep model. It is
leakage-inflated; true performance is ~0.67.

---

## Phase 5 — Build & register both models on Vertex AI

**Motivation (user decision):** register an honest model *and* the leaderboard-matching model as
separate versions for comparison.

**Constraint:** the Vertex prebuilt **XGBoost training container is v1.1** (no native categorical)
→ trainer must **one-hot encode**. Verified both numbers survive one-hot before building:
honest deduped 5+5 depth 6 → **0.6670**; raw no-dedup 5+5 depth 10 → **0.7025**.

**Final 10 features:** customer_master = `num_delayed_payments`, `credit_mix`,
`payment_of_min_amount`, `num_active_accounts`, `credit_score_bureau`; loan_applications =
`interest_rate_pct`, `dti_ratio`, `loan_amount`, `loan_term_months`, `approval_status`.

**Pipeline built (this folder):** `sql/build_features_honest.sql` (dedup **both** sides → 150,000
rows, fully leakage-free), `sql/build_features_leaky.sql` (no dedup → 165,373 rows),
`trainer/task.py` (shared, one-hot, hyperparams via args), `submit_training.py` (two jobs →
two versions of one registry model).

**Result — Vertex Custom Training Jobs, both `PIPELINE_STATE_SUCCEEDED`:**
Model `aegis-credit-risk-v2` (`.../models/6488104316052701184`):

| Version | Aliases | Table (rows) | AUC | Meaning |
|---|---|---|---|---|
| @1 | `honest`, `default`, `auc-0-660` | `ml_features_v2_honest` (150k) | **0.660** | leakage-free, generalizes |
| @2 | `leaderboard`, `auc-0-700` | `ml_features_v2_leaky` (165k) | **0.700** | matches peer; leakage-inflated |

(The honest 0.660 is slightly below the local 0.667 because the local "honest" data still had the
loan-side duplicate leakage; the registered table dedups *both* sides, so 0.660 is the truly clean
number.) Not deployed — scope was retrain + re-register.

---

## Summary table of every result

| # | Experiment | AUC | Takeaway |
|---|---|---|---|
| 0 | Production (one-hot, 38 cols, deduped) | 0.671 | baseline |
| A | BQML 19 raw | 0.652 | BQML underperforms XGBoost |
| B | BQML 19 cleaned | 0.635 | cleaning hurts |
| C | BQML 10 cleaned | 0.641 | selection+cleaning hurts |
| E | BQML 10 raw tuned | 0.661 | raw ≫ cleaned |
| F | BQML 19 raw tuned | 0.666 | best BQML |
| G | BQML 19 + engineered | 0.660 | ratios don't help |
| 3.1 | XGB full 16 (native) | 0.673 | > production |
| 3.2 | XGB forward-selected 5+5 | 0.673 | selection plateaus |
| 3.3 | XGB tuned (single split) | 0.679 | overfit optimism |
| 3.4 | XGB 5-fold CV (tuned) | 0.674 | train 0.81 → overfit |
| 3.5 | XGB regularized CV | **0.671** | **honest ceiling** |
| 4.2 | XGB clean-rows subset | 0.671 | no change |
| 4.4 | Grouped (leakage-free) | 0.667 | true performance |
| 4.4 | Random (leaked) | 0.691 | +0.023 leakage |
| 4.5 | Raw + depth 10 single split | **0.705** | the "peer 0.70" |
| 5 | Vertex @1 honest | **0.660** | registered, clean |
| 5 | Vertex @2 leaderboard | **0.700** | registered, leaked |

## Recommendation
Serve/submit the **honest @1 model (0.660)**. The 0.70 looks better but would behave like ~0.67
on genuinely new customers, and the missing dedup reads as a pipeline bug under review. The
leaderboard @2 version exists only to document and reproduce exactly how the peer number arises.
