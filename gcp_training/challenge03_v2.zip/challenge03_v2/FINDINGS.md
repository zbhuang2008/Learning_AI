# Challenge 3 — AUC Exploration Findings

**Question:** another team reached AUC > 0.70 with ~10 features (5 from `customer_master`,
5 from `loan_applications`); our deduped XGBoost model sits at 0.671. Why, and can we reach 0.70?

## TL;DR
The 0.70 is **train/test leakage**, not real signal. The honest, leakage-free ceiling on
this feature set is **~0.667–0.671** no matter how you select or tune features. Our existing
production model (0.671) is already at that ceiling and is the *honest* number.

## What we measured (local XGBoost, native categorical + NaN handling)

| Setup | AUC | Notes |
|---|---|---|
| Production (one-hot, 38 cols, deduped) | 0.671 | baseline |
| Full 16 features, deduped, 5-fold CV | 0.678 | single-split optimism |
| Full 16, deduped, **regularized CV** | **0.671** | honest generalization ceiling |
| Best 5+5, deduped, regularized CV | 0.670 | feature selection doesn't help |
| Clean-rows subset (drop dirty rows) | 0.671 | no change |
| BQML boosted tree (mean-imputes) | 0.652–0.666 | pessimistic proxy |
| **Raw (no dedup), random split, grouped CV** | **0.667** | leakage-free |
| **Raw (no dedup), random split, 5-fold** | **0.691** | +0.023 leakage |
| **Raw, 5+5, single split, depth 10** | **0.705** | ← the "other team" number |

## Root cause: duplicate rows + random split
- `customer_master`: 157,500 valid rows but only **150,000 distinct `customer_id`** (~7,500 dup customers).
- `loan_applications`: 160,650 rows but only **153,150 distinct `loan_id`** (dup loans).
- Joining **without dedup** yields 165,373 rows; a **random** 80/20 split puts the *same customer*
  in both train and test. A deep model (depth 10) memorizes those duplicates →
  measured AUC inflates by **+0.023**, crossing 0.70.
- A **customer-grouped split** (no customer in both sides) removes the inflation → 0.667.

## Signal reality (why ~0.67 is the ceiling)
Best single-feature AUCs are modest: `num_delayed_payments` 0.599, `interest_rate_pct` 0.578,
`credit_mix` 0.578, `num_active_accounts` 0.567, `credit_score_bureau` 0.558, `dti_ratio` 0.557,
`loan_amount` 0.557. `loan_purpose`, `loan_term_months`, `age`, `days_since_application`,
`temp_migration_flag`, `legacy_system_id`, and date components are ~noise. No leaky/strong feature exists.

## Implications / options
- **Honest model:** keep dedup → ~0.67 (defensible, generalizes to new customers).
- **Match the 0.70 leaderboard number:** drop dedup + random split + deeper model (5+5) → registry
  shows ~0.705. This is how the peer team got it, but it overstates true performance (~0.67).

## Registered outcome (Vertex AI Model Registry)
Model `aegis-credit-risk-v2` (`.../models/6488104316052701184`), two versions:

| Version | Alias | AUC | Table | Notes |
|---|---|---|---|---|
| @1 | `honest`, `default`, `auc-0-660` | **0.660** | `ml_features_v2_honest` (150k, deduped both sides) | leakage-free, generalizes |
| @2 | `leaderboard`, `auc-0-700` | **0.700** | `ml_features_v2_leaky` (165k, no dedup) | matches peer number; leakage-inflated |

Both trained as Vertex Custom Training Jobs (xgboost-cpu.1-1), one-hot 10 features (5+5),
`PIPELINE_STATE_SUCCEEDED`. Not deployed (retrain + re-register scope). Pipeline files:
`sql/build_features_honest.sql`, `sql/build_features_leaky.sql`, `trainer/task.py`, `submit_training.py`.

## Reproduce
Experiment scripts in `experiments/` (run with `PYTHONPATH=/tmp/pylibs`):
`harness.py` (baseline/importance), `select.py` (forward selection), `cv.py`/`regfast.py`
(honest CV), `leak.py` (random vs grouped), `repro70.py` (reproduces 0.705).
Data cached at `/tmp/credit_data.parquet` (deduped) and `/tmp/credit_raw.parquet` (raw).
