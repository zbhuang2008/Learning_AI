"""Challenge 3 v2 — Vertex AI Custom Training script (XGBoost, 10-feature model).

Reads a consolidated 10-feature table from BigQuery (5 customer_master + 5
loan_applications features) and trains a binary classifier for `default_flag`.

The same script trains both v2 models; the difference is purely the --bq-source
table and the hyperparameters passed in:
  * honest      -> ml_features_v2_honest (deduped, no leakage), shallow depth  -> AUC ~0.67
  * leaderboard -> ml_features_v2_leaky  (raw, dup customers),  deep model     -> AUC ~0.70

Uses XGBoost's native train()/DMatrix API and ONE-HOT encoding (the prebuilt
xgboost-cpu.1-1 training container is XGBoost 1.1 / Python 3.7 and has no native
categorical support). Writes model.bst + metrics.json + feature_columns.json to
$AIP_MODEL_DIR for registration / serving.
"""

import argparse
import json
import os

import pandas as pd
import xgboost as xgb
from google.cloud import bigquery, storage
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split

TARGET = "default_flag"
# 3 categoricals within the 10-feature set (one-hot encoded below).
CATEGORICAL = ["credit_mix", "payment_of_min_amount", "approval_status"]


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--project", required=True, help="GCP project id")
    p.add_argument("--bq-source", required=True, help="dataset.table of 10-feature data")
    p.add_argument("--auc-threshold", type=float, default=0.6)
    p.add_argument("--num-boost-round", type=int, default=400)
    p.add_argument("--max-depth", type=int, default=6)
    p.add_argument("--learning-rate", type=float, default=0.1)
    return p.parse_args()


def load_data(project, bq_source):
    client = bigquery.Client(project=project)
    print("Reading from `{}` ...".format(bq_source))
    df = client.query("SELECT * FROM `{}`".format(bq_source)).to_dataframe()
    print("Loaded {:,} rows, {} columns".format(len(df), df.shape[1]))
    return df


def preprocess(df):
    y = df[TARGET].astype(int)
    X = df.drop(columns=[TARGET])
    cats = [c for c in CATEGORICAL if c in X.columns]
    X = pd.get_dummies(X, columns=cats, dummy_na=True)
    X = X.apply(pd.to_numeric, errors="coerce").astype("float32")
    return X, y


def upload_dir_to_gcs(local_dir, gcs_dir):
    assert gcs_dir.startswith("gs://")
    bucket_name, _, prefix = gcs_dir[len("gs://"):].partition("/")
    bucket = storage.Client().bucket(bucket_name)
    for fname in os.listdir(local_dir):
        blob = bucket.blob("{}/{}".format(prefix, fname))
        blob.upload_from_filename(os.path.join(local_dir, fname))
        print("Uploaded {} -> gs://{}/{}/{}".format(fname, bucket_name, prefix, fname))


def main():
    args = parse_args()
    df = load_data(args.project, args.bq_source)
    X, y = preprocess(df)
    print("Feature matrix: {}; positive rate: {:.3f}".format(X.shape, y.mean()))

    # Stratified 80/20 split. NOTE: for the leaky table this random split is exactly
    # what lets duplicate customers leak across train/test (inflating AUC); for the
    # deduped honest table each customer appears once, so the same split is honest.
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    pos = int(y_train.sum())
    neg = int(len(y_train) - pos)
    spw = (neg / pos) if pos else 1.0

    dtrain = xgb.DMatrix(X_train, label=y_train)
    dtest = xgb.DMatrix(X_test, label=y_test)
    params = {
        "objective": "binary:logistic",
        "eval_metric": "auc",
        "max_depth": args.max_depth,
        "eta": args.learning_rate,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "scale_pos_weight": spw,
        "seed": 42,
    }
    booster = xgb.train(
        params, dtrain, num_boost_round=args.num_boost_round,
        evals=[(dtest, "test")], verbose_eval=50,
    )

    auc = float(roc_auc_score(y_test, booster.predict(dtest)))
    print("Test AUC: {:.4f}".format(auc))
    assert auc > args.auc_threshold, "AUC {:.4f} below threshold {}".format(
        auc, args.auc_threshold
    )

    local_dir = "/tmp/model_out"
    os.makedirs(local_dir, exist_ok=True)
    booster.save_model(os.path.join(local_dir, "model.bst"))
    with open(os.path.join(local_dir, "metrics.json"), "w") as f:
        json.dump({"auc": auc, "n_features": int(X.shape[1]),
                   "source": args.bq_source, "max_depth": args.max_depth}, f)
    with open(os.path.join(local_dir, "feature_columns.json"), "w") as f:
        json.dump(list(X.columns), f)

    model_dir = os.environ.get("AIP_MODEL_DIR")
    if model_dir:
        upload_dir_to_gcs(local_dir, model_dir.rstrip("/"))
        print("Artifacts written to {}".format(model_dir))
    else:
        print("AIP_MODEL_DIR not set; artifacts left in {}".format(local_dir))


if __name__ == "__main__":
    main()
