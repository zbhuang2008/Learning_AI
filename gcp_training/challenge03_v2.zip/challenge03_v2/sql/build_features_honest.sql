-- Challenge 3 v2 — HONEST feature table (leakage-free).
-- 10 features: 5 from customer_master + 5 from loan_applications. Target: default_flag.
-- Dedup customer_master to ONE row per customer_id so no customer can appear in both the
-- train and test split (this is what keeps the AUC honest, ~0.67).
-- Raw numeric values are kept as-is: XGBoost handles them, and the dirty extremes
-- (e.g. high num_delayed_payments) carry real signal — clipping them HURT in testing.
CREATE OR REPLACE TABLE `aegis_chronos_dwh.ml_features_v2_honest` AS
WITH cust AS (
  SELECT * EXCEPT(rn) FROM (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY loan_id) AS rn
    FROM `aegis_chronos_dwh.customer_master`
    WHERE default_flag IN (0, 1)              -- drop -999999 sentinel labels
  ) WHERE rn = 1                              -- one row per customer => no leakage
),
loans AS (
  -- loan_applications also has duplicate loan_ids; dedup so the join can't re-inflate
  -- the deduped customers (which would re-introduce leakage).
  SELECT * EXCEPT(rn) FROM (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY loan_id ORDER BY application_date) AS rn
    FROM `aegis_chronos_dwh.loan_applications`
  ) WHERE rn = 1
)
SELECT
  c.default_flag,
  -- 5 customer_master features
  SAFE_CAST(c.num_delayed_payments AS FLOAT64) AS num_delayed_payments,
  c.credit_mix,
  c.payment_of_min_amount,
  SAFE_CAST(c.num_active_accounts  AS FLOAT64) AS num_active_accounts,
  SAFE_CAST(c.credit_score_bureau  AS FLOAT64) AS credit_score_bureau,
  -- 5 loan_applications features
  SAFE_CAST(l.interest_rate_pct AS FLOAT64) AS interest_rate_pct,
  SAFE_CAST(l.dti_ratio         AS FLOAT64) AS dti_ratio,
  SAFE_CAST(l.loan_amount       AS FLOAT64) AS loan_amount,
  SAFE_CAST(l.loan_term_months  AS FLOAT64) AS loan_term_months,
  l.approval_status
FROM cust c
LEFT JOIN loans l ON c.loan_id = l.loan_id;
