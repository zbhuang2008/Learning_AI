-- Challenge 3 v2 — LEADERBOARD feature table (matches the peer team's ~0.70 number).
-- Identical 10 features to the honest table, but NO dedup on either side.
-- customer_master has duplicate customer_ids and loan_applications has duplicate loan_ids,
-- so this join (~165k rows from 150k customers) lets the SAME customer fall into both the
-- train and test split. A deep model memorizes those duplicates and the measured AUC
-- inflates by ~+0.023 (crossing 0.70). This is train/test LEAKAGE: true generalization
-- performance is still ~0.67 (see FINDINGS.md). Registered for comparison only.
CREATE OR REPLACE TABLE `aegis_chronos_dwh.ml_features_v2_leaky` AS
SELECT
  c.default_flag,
  -- 5 customer_master features
  SAFE_CAST(c.num_delayed_payments AS FLOAT64) AS num_delayed_payments,
  c.credit_mix,
  c.payment_of_min_amount,
  SAFE_CAST(c.num_active_accounts  AS FLOAT64) AS num_active_accounts,
  SAFE_CAST(c.credit_score_bureau  AS FLOAT64) AS credit_score_bureau,
  -- 5 loan_applications features
  SAFE_CAST(l.interest_rate_pct AS FLOAT64) AS interest_rate_pct,
  SAFE_CAST(l.dti_ratio         AS FLOAT64) AS dti_ratio,
  SAFE_CAST(l.loan_amount       AS FLOAT64) AS loan_amount,
  SAFE_CAST(l.loan_term_months  AS FLOAT64) AS loan_term_months,
  l.approval_status
FROM `aegis_chronos_dwh.customer_master` c
JOIN `aegis_chronos_dwh.loan_applications` l ON c.loan_id = l.loan_id  -- no dedup
WHERE c.default_flag IN (0, 1);
