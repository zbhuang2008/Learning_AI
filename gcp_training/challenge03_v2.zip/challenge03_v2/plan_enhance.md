# Plan — Push Challenge 3 AUC from 0.671 to 0.70+ (Project Predictor)

> On approval this file will be saved to
> `/home/student_00_4506436fdd0a/challenge03_v2/plan_enhance.md`.

## Context

Challenge 3 is already complete end-to-end: an XGBoost model predicting `default_flag`
is trained on Vertex AI, registered, and deployed at **AUC = 0.671**. Another team
reportedly reached **>0.70 with ~10 features**. We want to close that gap.

I profiled the live data in BigQuery (read-only) to find the cause. There are **no
hidden high-signal columns** — the current pipeline already pulls every available
feature. The 0.671 ceiling comes from two concrete defects in the current
`ml_credit_features` build + trainer:

1. **The two strongest predictors are fed to XGBoost as dirty raw values.**
   - `num_delayed_payments` — strongest signal (corr **0.169**) but ranges **-3 to 4399**.
   - `num_active_accounts` — corr **0.111** but ranges **-100 to 2584**.
   These garbage outliers/negatives corrupt tree splits on exactly the features that matter most.

2. **~10 real signals are diluted across 38 one-hot columns of mostly noise/empty data.**
   - Pure-noise features still included: `monthly_income_usd` (corr ~0.0005),
     `dti_ratio` (~0.007, also dirty: max 4997), `age` (0.017), `loan_term_months` (0.003),
     and `loan_purpose` (zero class separation — every value ~0.37 default rate, expands to a 6-way one-hot).
   - Near-empty LEFT-JOIN features: the 4 bank columns are populated for only **2,097 / 157,500**
     rows (1.3%) and the bureau column for **10,490** (6.7%). They contribute almost nothing but add NaN-heavy splits.

### Signal map (measured)

| Keep (~10 high-signal) | Type | Signal | Action |
|---|---|---|---|
| `num_delayed_payments` | num | **0.169** | **clean: keep 0–60, else NULL** |
| `credit_mix` | cat | **strong** (BAD 0.52 / GOOD 0.31) | map `_` → NULL |
| `interest_rate_pct` | num | 0.130 | keep |
| `credit_score_bureau` | num | 0.112 | keep (already clean 300–850) |
| `num_active_accounts` | num | 0.111 | **clean: keep 0–40, else NULL** |
| `loan_amount` | num | 0.097 | keep |
| `years_at_residence` | num | 0.087 | keep |
| `residence_type` | cat | moderate | keep |
| `approval_status` | cat | moderate | keep |
| `payment_of_min_amount` | cat | weak | keep (drop in ablation if it hurts) |

| Drop (noise / near-empty) | Reason |
|---|---|
| `monthly_income_usd`, `dti_ratio`, `age`, `loan_term_months` | corr ≈ 0 |
| `loan_purpose` | no class separation; bloats one-hot |
| `avg_daily_balance`, `total_deposits`, `total_withdrawals`, `num_overdrafts` | 1.3% populated |
| `total_hard_inquiries_last_6m` | 6.7% populated |

## Approach

Iterate fast with **BigQuery ML** (`BOOSTED_TREE_CLASSIFIER`, ~1–2 min/run, AUC for free),
lock the winning feature set, then run the real Vertex job **once** and re-register.

### Step 1 — Fast feature/cleaning experiments in BigQuery ML
Work in a scratch dataset/table; do not touch the production table yet. For each
experiment, train and read `roc_auc` from `ML.EVALUATE`.

- **Exp A (baseline parity):** BQML boosted tree on the *current* 19-feature set → confirm it lands ~0.67. Establishes the BQML-vs-Vertex offset.
- **Exp B (clean only):** same features but clip the two dirty columns to NULL outside
  `[0,60]` / `[0,40]` and map `credit_mix='_'` → NULL. Measures the cleaning lift alone.
- **Exp C (select + clean):** the ~10-feature shortlist above, cleaned. Expected primary win.
- **Exp D (ablation):** from C, drop `payment_of_min_amount`; optionally test adding back
  one borderline feature (`loan_amount`/`years_at_residence`) to confirm they help.
- Pick the feature set with the best held-out AUC (BQML uses an internal split;
  use `DATA_SPLIT_METHOD='RANDOM', DATA_SPLIT_EVAL_FRACTION=0.2` for a clean comparison).

Representative BQML call (each experiment is one `CREATE MODEL`):
```sql
CREATE OR REPLACE MODEL `aegis_chronos_dwh.exp_credit_c`
OPTIONS(model_type='BOOSTED_TREE_CLASSIFIER', input_label_cols=['default_flag'],
        max_iterations=200, learn_rate=0.1, subsample=0.8,
        data_split_method='RANDOM', data_split_eval_fraction=0.2, auto_class_weights=TRUE) AS
SELECT default_flag, <shortlist features with cleaning CASE/NULLIF logic>
FROM `aegis_chronos_dwh.customer_master` c
LEFT JOIN `aegis_chronos_dwh.loan_applications` l USING(loan_id)  -- dedup as today
WHERE c.default_flag IN (0,1);
-- AUC: SELECT roc_auc FROM ML.EVALUATE(MODEL `...exp_credit_c`);
```

If BQML already shows the cleaned shortlist comfortably >0.70, that validates the
hypothesis before any Vertex run. If it lands ~0.69, add a light hyperparameter pass
(below) inside BQML before committing.

### Step 2 — Light hyperparameter tuning (only if needed)
On the winning feature set, sweep a small grid (BQML `max_tree_depth` 4/6/8,
`max_iterations` with `early_stop=TRUE`, `learn_rate` 0.05/0.1). Tree models gain
little past this; the feature fix is the main lever.

### Step 3 — Port the winner to the production pipeline (work in `challenge03_v2/`)
Copy and modify the existing, working assets from `../challenge03/` rather than
rewriting:
- **`sql/build_features.sql`** — rebuild `ml_credit_features` (or a v2 table) with:
  only the shortlist columns; the cleaning `CASE`/`NULLIF` logic baked in (clip
  `num_delayed_payments`/`num_active_accounts`, `NULLIF(credit_mix,'_')`); drop the
  bank/bureau joins and the noise columns. Keep the existing dedup + `default_flag IN (0,1)` filter.
- **`trainer/task.py`** — same native-XGBoost structure; update `CATEGORICAL` to the
  kept categoricals (remove `loan_purpose`), apply the winning hyperparameters, add
  **`early_stopping_rounds`** with a watchlist to prevent the 400-round overfit. Keep
  `metrics.json` / `feature_columns.json` / `model.bst` outputs unchanged.
- **`submit_training.py`** — point `BQ_SOURCE` at the new table; reuse the same
  containers, machine type, and the AUC-as-label registration. Bump
  `MODEL_DISPLAY_NAME` or rely on Model Registry versioning so the better model
  registers as a new **version** alongside the 0.671 one.

### Step 4 — Retrain + re-register on Vertex AI
Run `python3 submit_training.py`. Confirm the job `SUCCEEDED`, the printed test AUC
is **>0.70** (and clears the 0.6 DoD bar), and a new model version appears in the
Registry with the AUC label. **No redeploy** this round (per decision).

## Files
- New (under `challenge03_v2/`): `plan_enhance.md`, `sql/build_features.sql`,
  `trainer/task.py`, `trainer/requirements.txt`, `submit_training.py` — adapted from `../challenge03/`.
- Scratch BQML models in `aegis_chronos_dwh` (e.g. `exp_credit_*`) — throwaway, drop after.

## Verification
1. **BQML experiments:** `ML.EVALUATE` `roc_auc` for the cleaned shortlist > current
   ~0.67 baseline, ideally ≥0.70. Record each experiment's AUC in the plan/summary.
2. **Feature table:** query the rebuilt table — row count ≈157,500, no `-999999`,
   dirty columns clipped (max within sane range), only shortlist columns present.
3. **Vertex job:** pipeline state `SUCCEEDED`; trainer log prints test AUC > 0.70.
4. **Registry:** `gcloud ai models list --region=us-central1` shows the new
   `aegis-credit-risk-xgb` version with the updated `auc_0_7xx` label; `model.bst`
   present in the new artifact dir.

## Notes / risks
- BQML AUC ≠ Vertex AUC exactly (different split/impl), so treat BQML as relative
  ranking of feature sets; the Vertex run in Step 4 is the number of record.
- If the cleaned shortlist lands at ~0.69 not 0.70, the remaining lift is most likely
  in `credit_mix`/`credit_score_bureau` interactions or modest depth tuning — Step 2 covers it.
- Keep the old 0.671 model/version registered for comparison; we add a version, not overwrite.
