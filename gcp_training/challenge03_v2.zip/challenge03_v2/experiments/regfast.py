import warnings; warnings.filterwarnings("ignore")
import numpy as np, xgboost as xgb
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score
from harness import df, prep, TARGET, ALL
CUST5=["num_delayed_payments","credit_mix","payment_of_min_amount","num_active_accounts","credit_score_bureau"]
LOAN5=["interest_rate_pct","dti_ratio","loan_amount","days_since_application","approval_status"]
TEN=CUST5+LOAN5
def cv(feats,params,k=3):
    X=prep(df[feats]); y=df[TARGET].astype(int).values
    skf=StratifiedKFold(n_splits=k,shuffle=True,random_state=42); aucs=[]
    for tri,tei in skf.split(X,y):
        dtr=xgb.DMatrix(X.iloc[tri],label=y[tri],enable_categorical=True)
        dte=xgb.DMatrix(X.iloc[tei],label=y[tei],enable_categorical=True)
        bst=xgb.train(params,dtr,num_boost_round=600,evals=[(dte,"t")],early_stopping_rounds=40,verbose_eval=False)
        aucs.append(roc_auc_score(y[tei],bst.predict(dte,iteration_range=(0,bst.best_iteration+1))))
    return float(np.mean(aucs))
base=dict(objective="binary:logistic",eval_metric="auc",eta=0.05,tree_method="hist",seed=42,subsample=0.8,colsample_bytree=0.8)
configs=[dict(max_depth=d,min_child_weight=m,reg_lambda=l) for d,m,l in
         [(3,50,10),(4,50,10),(4,100,20),(5,50,10),(5,100,30),(6,100,50)]]
print("Regularized CV (3-fold) on FULL16:",flush=True)
best=(None,0)
for c in configs:
    p=dict(base,**c); a=cv(ALL,p)
    print(f"  {a:.4f}  {c}",flush=True)
    if a>best[1]: best=(p,a)
print(f">>> FULL16 best CV = {best[1]:.4f}",flush=True)
print(f">>> TEN(5+5) same params = {cv(TEN,best[0]):.4f}",flush=True)
