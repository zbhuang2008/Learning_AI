import warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd, xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
d=pd.read_parquet("/tmp/credit_raw.parquet")
CATS=["residence_type","payment_of_min_amount","credit_mix","loan_purpose","approval_status"]
CUST5=["num_delayed_payments","credit_mix","payment_of_min_amount","num_active_accounts","credit_score_bureau"]
LOAN5=["interest_rate_pct","dti_ratio","loan_amount","days_since_application","approval_status"]
TEN=CUST5+LOAN5
def prep(X):
    X=X.copy()
    for c in X.columns:
        X[c]=X[c].astype("category") if c in CATS else pd.to_numeric(X[c],errors="coerce").astype("float32")
    return X
def single(feats,depth,rounds,seed=42):
    X=prep(d[feats]); y=d.default_flag.astype(int)
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=0.2,stratify=y,random_state=seed)
    p=dict(objective="binary:logistic",eval_metric="auc",max_depth=depth,eta=0.1,
           subsample=0.8,colsample_bytree=0.8,tree_method="hist",seed=seed)
    b=xgb.train(p,xgb.DMatrix(Xtr,label=ytr,enable_categorical=True),num_boost_round=rounds)
    return roc_auc_score(yte,b.predict(xgb.DMatrix(Xte,label=yte,enable_categorical=True)))
print("RAW data, single 80/20 random split (registry-style number, WITH leakage):")
for feats,name in [(TEN,"TEN(5+5)")]:
    for depth,rounds in [(6,400),(8,500),(10,600)]:
        print(f"  {name} depth={depth} rounds={rounds}: AUC {single(feats,depth,rounds):.4f}")
