import warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd, xgboost as xgb
from sklearn.model_selection import StratifiedKFold, StratifiedGroupKFold
from sklearn.metrics import roc_auc_score
d=pd.read_parquet("/tmp/credit_raw.parquet")
CATS=["residence_type","payment_of_min_amount","credit_mix","loan_purpose","approval_status"]
FEATS=[c for c in d.columns if c not in ("default_flag","customer_id")]
def prep(X):
    X=X.copy()
    for c in X.columns:
        X[c]=X[c].astype("category") if c in CATS else pd.to_numeric(X[c],errors="coerce").astype("float32")
    return X
X=prep(d[FEATS]); y=d.default_flag.astype(int).values; grp=d.customer_id.values
P=dict(objective="binary:logistic",eval_metric="auc",max_depth=8,eta=0.05,subsample=0.8,
       colsample_bytree=0.8,tree_method="hist",seed=42)
def run(splitter,groups=None):
    aucs=[]
    for tri,tei in splitter.split(X,y,groups):
        dtr=xgb.DMatrix(X.iloc[tri],label=y[tri],enable_categorical=True)
        dte=xgb.DMatrix(X.iloc[tei],label=y[tei],enable_categorical=True)
        b=xgb.train(P,dtr,num_boost_round=400,evals=[(dte,"t")],early_stopping_rounds=30,verbose_eval=False)
        aucs.append(roc_auc_score(y[tei],b.predict(dte,iteration_range=(0,b.best_iteration+1))))
    return np.mean(aucs)
rnd=run(StratifiedKFold(5,shuffle=True,random_state=42))
grpcv=run(StratifiedGroupKFold(5),grp)
print(f"RANDOM split  (customer can leak across train/test): AUC {rnd:.4f}")
print(f"GROUPED split (no customer leakage)                : AUC {grpcv:.4f}")
print(f"Leakage inflation = {rnd-grpcv:+.4f}")
