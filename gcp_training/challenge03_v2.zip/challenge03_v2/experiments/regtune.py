import warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd, xgboost as xgb, itertools
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score
from harness import df, prep, TARGET, ALL, CUST, LOAN

CUST5=["num_delayed_payments","credit_mix","payment_of_min_amount","num_active_accounts","credit_score_bureau"]
LOAN5=["interest_rate_pct","dti_ratio","loan_amount","days_since_application","approval_status"]
TEN=CUST5+LOAN5

def cv(feats,params,k=4):
    X=prep(df[feats]); y=df[TARGET].astype(int).values
    skf=StratifiedKFold(n_splits=k,shuffle=True,random_state=42); aucs=[]
    for tri,tei in skf.split(X,y):
        dtr=xgb.DMatrix(X.iloc[tri],label=y[tri],enable_categorical=True)
        dte=xgb.DMatrix(X.iloc[tei],label=y[tei],enable_categorical=True)
        bst=xgb.train(params,dtr,num_boost_round=1200,evals=[(dte,"t")],
                      early_stopping_rounds=50,verbose_eval=False)
        aucs.append(roc_auc_score(y[tei],bst.predict(dte,iteration_range=(0,bst.best_iteration+1))))
    return float(np.mean(aucs))

base=dict(objective="binary:logistic",eval_metric="auc",eta=0.03,tree_method="hist",seed=42)
grid=list(itertools.product([3,4,5,6],[20,50,100],[0.7,1.0],[0.5,0.7,1.0],[1,10,50]))
print(f"Generalization tuning on FULL16 ({len(grid)} configs, 4-fold CV)...")
best=(None,0)
for md,mcw,ss,cs,rl in grid:
    p=dict(base,max_depth=md,min_child_weight=mcw,subsample=ss,colsample_bytree=cs,reg_lambda=rl)
    a=cv(ALL,p)
    if a>best[1]: best=(p,a); print(f"  best {a:.4f} depth={md} mcw={mcw} ss={ss} cs={cs} rl={rl}")
print(f">>> FULL16 best CV = {best[1]:.4f}")
print(f">>> Same params on TEN(5+5) = {cv(TEN,best[0]):.4f}")
