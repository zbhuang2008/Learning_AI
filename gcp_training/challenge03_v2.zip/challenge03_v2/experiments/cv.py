import warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd, xgboost as xgb
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score
from harness import df, prep, TARGET, CUST, LOAN, ALL

CUST5=["num_delayed_payments","credit_mix","payment_of_min_amount","num_active_accounts","credit_score_bureau"]
LOAN5=["interest_rate_pct","dti_ratio","loan_amount","days_since_application","approval_status"]
TEN=CUST5+LOAN5
TUNED=dict(objective="binary:logistic",eval_metric="auc",max_depth=10,eta=0.05,
           min_child_weight=1,subsample=1.0,colsample_bytree=0.6,reg_lambda=1,gamma=1,
           tree_method="hist",seed=42)

def cv(feats, params, k=5):
    X=prep(df[feats]); y=df[TARGET].astype(int).values
    skf=StratifiedKFold(n_splits=k,shuffle=True,random_state=42)
    tr_aucs,te_aucs=[],[]
    for tri,tei in skf.split(X,y):
        dtr=xgb.DMatrix(X.iloc[tri],label=y[tri],enable_categorical=True)
        dte=xgb.DMatrix(X.iloc[tei],label=y[tei],enable_categorical=True)
        bst=xgb.train(params,dtr,num_boost_round=800,evals=[(dte,"t")],
                      early_stopping_rounds=40,verbose_eval=False)
        it=(0,bst.best_iteration+1)
        te_aucs.append(roc_auc_score(y[tei],bst.predict(dte,iteration_range=it)))
        tr_aucs.append(roc_auc_score(y[tri],bst.predict(dtr,iteration_range=it)))
    return np.mean(te_aucs),np.std(te_aucs),np.mean(tr_aucs)

for name,feats in [("TEN(5+5)",TEN),("FULL16",ALL)]:
    te,sd,tr=cv(feats,TUNED)
    print(f"{name:10s} CV test AUC {te:.4f} +/- {sd:.4f}   (train {tr:.4f})")
