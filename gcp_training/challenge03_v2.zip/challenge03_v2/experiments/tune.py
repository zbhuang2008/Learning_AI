import warnings; warnings.filterwarnings("ignore")
import itertools, random
from harness import auc, CUST, LOAN, ALL

CUST5=["num_delayed_payments","credit_mix","payment_of_min_amount","num_active_accounts","credit_score_bureau"]
LOAN5=["interest_rate_pct","dti_ratio","loan_amount","days_since_application","approval_status"]
TEN=CUST5+LOAN5

grid=dict(
  max_depth=[4,5,6,8,10],
  eta=[0.02,0.03,0.05],
  min_child_weight=[1,5,20,50],
  subsample=[0.7,0.8,1.0],
  colsample_bytree=[0.6,0.8,1.0],
  reg_lambda=[1,5,20],
  gamma=[0,1,5],
)
random.seed(0)
def sample(): return {k:random.choice(v) for k,v in grid.items()}

for name,feats in [("TEN(5+5)",TEN),("FULL16",ALL)]:
    base,_=auc(feats)
    print(f"\n== {name}: baseline AUC {base:.4f} ==")
    best=(None,base)
    for i in range(25):
        p=sample()
        a,_=auc(feats,params=p,rounds=800)
        if a>best[1]: best=(p,a); print(f"  new best {a:.4f}  {p}")
    print(f"  >>> {name} best = {best[1]:.4f}")
