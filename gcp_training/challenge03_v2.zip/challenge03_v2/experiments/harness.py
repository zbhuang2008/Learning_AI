import warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd, xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score

df = pd.read_parquet("/tmp/credit_data.parquet")
TARGET="default_flag"
CATS=["residence_type","payment_of_min_amount","credit_mix","loan_purpose","approval_status"]
CUST=["residence_type","years_at_residence","monthly_income_usd","credit_score_bureau",
      "num_active_accounts","num_delayed_payments","payment_of_min_amount","credit_mix","age"]
LOAN=["loan_amount","loan_term_months","loan_purpose","dti_ratio","interest_rate_pct",
      "approval_status","days_since_application"]
ALL=CUST+LOAN

def prep(X):
    X=X.copy()
    for c in X.columns:
        if c in CATS: X[c]=X[c].astype("category")
        else: X[c]=pd.to_numeric(X[c],errors="coerce").astype("float32")
    return X

def auc(features, params=None, seed=42, rounds=600):
    X=prep(df[features]); y=df[TARGET].astype(int)
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=0.2,stratify=y,random_state=seed)
    p=dict(objective="binary:logistic",eval_metric="auc",max_depth=6,eta=0.05,
           subsample=0.8,colsample_bytree=0.8,tree_method="hist",seed=seed)
    if params: p.update(params)
    dtr=xgb.DMatrix(Xtr,label=ytr,enable_categorical=True)
    dte=xgb.DMatrix(Xte,label=yte,enable_categorical=True)
    bst=xgb.train(p,dtr,num_boost_round=rounds,evals=[(dte,"t")],
                  early_stopping_rounds=40,verbose_eval=False)
    a=roc_auc_score(yte,bst.predict(dte,iteration_range=(0,bst.best_iteration+1)))
    return a,bst

if __name__=="__main__":
    a,bst=auc(ALL)
    print(f"FULL 16-feature AUC = {a:.4f}  (best_iter={bst.best_iteration})")
    # per-feature single AUC
    print("\nSingle-feature AUC:")
    rows=[]
    for f in ALL:
        sa,_=auc([f]); rows.append((f,sa))
    for f,sa in sorted(rows,key=lambda x:-x[1]):
        tbl="CUST" if f in CUST else "LOAN"
        print(f"  {tbl}  {f:24s} {sa:.4f}")
    # importance (gain) from full model
    print("\nGain importance (full model):")
    imp=bst.get_score(importance_type="gain")
    for f,v in sorted(imp.items(),key=lambda x:-x[1]):
        print(f"  {f:24s} {v:9.1f}")
