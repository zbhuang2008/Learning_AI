import os
os.environ.setdefault("TMPDIR","/tmp")
from google.cloud import bigquery
PROJECT="qwiklabs-gcp-04-dc4fc3cbfb41"
client=bigquery.Client(project=PROJECT)
# Mirror production: dedup customer_master (1 row/customer), drop -999999, join loan on loan_id.
# Keep ALL candidate cols from customer_master (5+) and loan_applications (5+) so we can
# experiment with feature subsets in memory. No bank/bureau (per the 5+5 recipe).
SQL = """
WITH cust AS (
  SELECT * EXCEPT(rn) FROM (
    SELECT *, ROW_NUMBER() OVER(PARTITION BY customer_id ORDER BY loan_id) rn
    FROM `aegis_chronos_dwh.customer_master` WHERE default_flag IN (0,1)
  ) WHERE rn=1
)
SELECT
  c.default_flag,
  -- customer_master candidates
  c.residence_type, c.years_at_residence, c.monthly_income_usd, c.credit_score_bureau,
  c.num_active_accounts, c.num_delayed_payments, c.payment_of_min_amount, c.credit_mix,
  DATE_DIFF(CURRENT_DATE(), c.date_of_birth, YEAR) AS age,
  -- loan_applications candidates
  l.loan_amount, l.loan_term_months, l.loan_purpose, l.dti_ratio, l.interest_rate_pct,
  l.approval_status, DATE_DIFF(CURRENT_DATE(), l.application_date, DAY) AS days_since_application
FROM cust c
LEFT JOIN `aegis_chronos_dwh.loan_applications` l ON c.loan_id = l.loan_id
"""
df = client.query(SQL).to_dataframe()
print("rows", len(df), "cols", df.shape[1])
df.to_parquet("/tmp/credit_data.parquet")
print("cached -> /tmp/credit_data.parquet")
