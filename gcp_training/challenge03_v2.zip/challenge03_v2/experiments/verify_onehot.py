import warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd, xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
CUST5=["num_delayed_payments","credit_mix","payment_of_min_amount","num_active_accounts","credit_score_bureau"]
LOAN5=["interest_rate_pct","dti_ratio","loan_amount","loan_term_months","approval_status"]
TEN=CUST5+LOAN5
CATS=["credit_mix","payment_of_min_amount","approval_status"]
def prep(df):
    X=df[TEN].copy()
    X=pd.get_dummies(X,columns=CATS,dummy_na=True)
    return X.apply(pd.to_numeric,errors="coerce").astype("float32")
def run(path,depth,rounds,label):
    df=pd.read_parquet(path); y=df.default_flag.astype(int); X=prep(df)
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=0.2,stratify=y,random_state=42)
    spw=(len(ytr)-ytr.sum())/ytr.sum()
    p=dict(objective="binary:logistic",eval_metric="auc",max_depth=depth,eta=0.1,
           subsample=0.8,colsample_bytree=0.8,scale_pos_weight=spw,seed=42)
    b=xgb.train(p,xgb.DMatrix(Xtr,label=ytr),num_boost_round=rounds)
    a=roc_auc_score(yte,b.predict(xgb.DMatrix(Xte,label=yte)))
    print(f"  {label}: one-hot {X.shape[1]} cols, depth={depth}, rounds={rounds} -> AUC {a:.4f}")
print("HONEST (deduped table, /tmp/credit_data.parquet):")
run("/tmp/credit_data.parquet",6,400,"honest depth6")
print("LEADERBOARD (raw no-dedup, /tmp/credit_raw.parquet):")
run("/tmp/credit_raw.parquet",10,600,"leaky depth10")
