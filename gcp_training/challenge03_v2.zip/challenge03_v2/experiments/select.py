import warnings; warnings.filterwarnings("ignore")
import pandas as pd
from harness import auc, CUST, LOAN

def fwd(cap_cust=5, cap_loan=5, fast=dict(eta=0.1)):
    chosen=[]; nc=nl=0
    pool=CUST+LOAN
    while len(chosen)<cap_cust+cap_loan:
        best=None
        for f in pool:
            if f in chosen: continue
            if f in CUST and nc>=cap_cust: continue
            if f in LOAN and nl>=cap_loan: continue
            a,_=auc(chosen+[f], params=fast, rounds=300)
            if best is None or a>best[1]: best=(f,a)
        f,a=best; chosen.append(f)
        if f in CUST: nc+=1
        else: nl+=1
        tbl="CUST" if f in CUST else "LOAN"
        print(f"  +{tbl} {f:24s} -> AUC {a:.4f}  ({nc}c/{nl}l)")
    return chosen

print("Greedy forward selection (5 cust + 5 loan):")
best10=fwd()
print("\nFinal 10:", best10)
a,_=auc(best10)
print(f"10-feature AUC (eval params) = {a:.4f}")
