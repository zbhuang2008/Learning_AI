import os; os.environ.setdefault("TMPDIR","/tmp")
from google.cloud import bigquery
c=bigquery.Client(project="qwiklabs-gcp-04-dc4fc3cbfb41")
# RAW: no dedup on either side. customer_master JOIN loan_applications on loan_id.
SQL="""
SELECT c.customer_id, c.default_flag,
  c.residence_type,c.years_at_residence,c.monthly_income_usd,c.credit_score_bureau,
  c.num_active_accounts,c.num_delayed_payments,c.payment_of_min_amount,c.credit_mix,
  DATE_DIFF(CURRENT_DATE(),c.date_of_birth,YEAR) age,
  l.loan_amount,l.loan_term_months,l.loan_purpose,l.dti_ratio,l.interest_rate_pct,
  l.approval_status,DATE_DIFF(CURRENT_DATE(),l.application_date,DAY) days_since_application
FROM `aegis_chronos_dwh.customer_master` c
JOIN `aegis_chronos_dwh.loan_applications` l ON c.loan_id=l.loan_id
WHERE c.default_flag IN (0,1)
"""
df=c.query(SQL).to_dataframe()
print("raw joined rows",len(df),"distinct customers",df.customer_id.nunique())
df.to_parquet("/tmp/credit_raw.parquet"); print("cached")
