import warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd, xgboost as xgb
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score
from harness import df, prep, TARGET, ALL

CUST5=["num_delayed_payments","credit_mix","payment_of_min_amount","num_active_accounts","credit_score_bureau"]
LOAN5=["interest_rate_pct","dti_ratio","loan_amount","days_since_application","approval_status"]
TEN=CUST5+LOAN5
P=dict(objective="binary:logistic",eval_metric="auc",max_depth=5,eta=0.03,
       min_child_weight=50,subsample=0.8,colsample_bytree=0.7,reg_lambda=10,tree_method="hist",seed=42)

def cv(d,feats,k=5):
    X=prep(d[feats]); y=d[TARGET].astype(int).values
    skf=StratifiedKFold(n_splits=k,shuffle=True,random_state=42); aucs=[]
    for tri,tei in skf.split(X,y):
        dtr=xgb.DMatrix(X.iloc[tri],label=y[tri],enable_categorical=True)
        dte=xgb.DMatrix(X.iloc[tei],label=y[tei],enable_categorical=True)
        bst=xgb.train(P,dtr,num_boost_round=1200,evals=[(dte,"t")],early_stopping_rounds=50,verbose_eval=False)
        aucs.append(roc_auc_score(y[tei],bst.predict(dte,iteration_range=(0,bst.best_iteration+1))))
    return np.mean(aucs),len(d)

clean = df[
    (df.num_delayed_payments.between(0,50)) &
    (df.num_active_accounts.between(0,30)) &
    (df.dti_ratio.between(0,100)) &
    (df.monthly_income_usd.between(0,500000)) &
    (df.credit_mix!="_")
].copy()

print("full rows", len(df), "clean rows", len(clean))
a,_=cv(df,TEN);   print(f"TEN  on FULL  CV AUC {a:.4f}")
a,_=cv(clean,TEN);print(f"TEN  on CLEAN CV AUC {a:.4f}")
a,_=cv(clean,ALL);print(f"FULL on CLEAN CV AUC {a:.4f}")
